package com.irctc.trainmain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrainTicketReservationApplicationTests {

	@Test
	void contextLoads() {
	}

}
